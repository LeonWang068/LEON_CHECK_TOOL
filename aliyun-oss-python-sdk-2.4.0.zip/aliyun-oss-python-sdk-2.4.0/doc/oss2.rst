oss2 package
============

Submodules
----------

oss2.api module
---------------

.. automodule:: oss2.api
    :members:
    :undoc-members:
    :show-inheritance:

oss.auth module
---------------

.. automodule:: oss2.auth
    :members:
    :undoc-members:
    :show-inheritance:

oss.compat module
-----------------

.. automodule:: oss2.compat
    :members:
    :undoc-members:
    :show-inheritance:

oss.defaults module
-------------------

.. automodule:: oss2.defaults
    :members:
    :undoc-members:
    :show-inheritance:

oss.exceptions module
---------------------

.. automodule:: oss2.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

oss.http module
---------------

.. automodule:: oss2.http
    :members:
    :undoc-members:
    :show-inheritance:

oss.iterators module
--------------------

.. automodule:: oss2.iterators
    :members:
    :undoc-members:
    :show-inheritance:

oss.models module
-----------------

.. automodule:: oss2.models
    :members:
    :undoc-members:
    :show-inheritance:

oss.resumable module
--------------------

.. automodule:: oss2.resumable
    :members:
    :undoc-members:
    :show-inheritance:

oss.utils module
----------------

.. automodule:: oss2.utils
    :members:
    :undoc-members:
    :show-inheritance:

oss.xml_utils module
--------------------

.. automodule:: oss2.xml_utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: oss2
    :members:
    :undoc-members:
    :show-inheritance:
