.. oss documentation master file, created by
   sphinx-quickstart on Tue Dec 01 12:00:37 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Aliyun OSS SDK for Python
=========================


开发文档
--------

.. toctree::
   :maxdepth: 2

   api


.. toctree::
   :maxdepth: 2

   easy


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

